<?php
 
return array(
    'connection' => 'mysql-wordpress',
);
 
?>
