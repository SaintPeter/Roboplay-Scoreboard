<?php

class Score_runsTableSeeder extends Seeder {

	public function run()
	{
		// Uncomment the below to wipe the table clean before populating
		// DB::table('score_runs')->truncate();

		$score_runs = array(

		);

		// Uncomment the below to run the seeder
		// DB::table('score_runs')->insert($score_runs);
	}

}
