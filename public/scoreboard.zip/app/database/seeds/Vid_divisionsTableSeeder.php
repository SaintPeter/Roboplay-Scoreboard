<?php

class Vid_divisionsTableSeeder extends Seeder {

	public function run()
	{
		// Uncomment the below to wipe the table clean before populating
		// DB::table('vid_divisions')->truncate();

		$vid_divisions = array(

		);

		// Uncomment the below to run the seeder
		// DB::table('vid_divisions')->insert($vid_divisions);
	}

}
