<?php

class Score_elementsTableSeeder extends Seeder {

	public function run()
	{
		// Uncomment the below to wipe the table clean before populating
		// DB::table('score_elements')->truncate();

		$score_elements = array(

		);

		// Uncomment the below to run the seeder
		// DB::table('score_elements')->insert($score_elements);
	}

}
