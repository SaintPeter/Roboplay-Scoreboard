<?php

class VideosTableSeeder extends Seeder {

	public function run()
	{
		// Uncomment the below to wipe the table clean before populating
		// DB::table('videos')->truncate();

		$videos = array(

		);

		// Uncomment the below to run the seeder
		// DB::table('videos')->insert($videos);
	}

}
