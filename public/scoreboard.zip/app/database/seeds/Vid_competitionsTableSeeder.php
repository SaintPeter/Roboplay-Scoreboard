<?php

class Vid_competitionsTableSeeder extends Seeder {

	public function run()
	{
		// Uncomment the below to wipe the table clean before populating
		// DB::table('vid_competitions')->truncate();

		$vid_competitions = array(

		);

		// Uncomment the below to run the seeder
		// DB::table('vid_competitions')->insert($vid_competitions);
	}

}
