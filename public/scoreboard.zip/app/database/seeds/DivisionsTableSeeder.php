<?php

class DivisionsTableSeeder extends Seeder {

	public function run()
	{
		// Uncomment the below to wipe the table clean before populating
		// DB::table('divisions')->truncate();

		$divisions = array(

		);

		// Uncomment the below to run the seeder
		// DB::table('divisions')->insert($divisions);
	}

}
